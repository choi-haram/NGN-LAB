#! /bin/sh

echo "패스워드 만료 경고일 설정"
echo "패스워드 만료 경고일 설정" >> $HOSTNAME-result.txt 2>&1
PASSWARNAGE=`grep PASS_WARN_AGE /etc/login.defs | grep -v "^#" | awk '{ print $2 }'`
if [ $PASSWARNAGE ] ; then
   if [ $PASSWARNAGE -eq 7 ] ; then
      echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]양호"  
   else 
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약" 
   fi
else
   echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약"
fi

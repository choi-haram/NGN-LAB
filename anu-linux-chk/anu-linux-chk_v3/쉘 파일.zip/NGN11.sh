#! /bin/sh

echo "패스워드 최소길이 설정"
echo "패스워드 최소길이 설정" >> $HOSTNAME-result.txt 2>&1
PASSMINLEN=`grep PASS_MIN_LEN /etc/login.defs | grep -v "^#" | awk '{ print $2 }'`
if [ $PASSMINLEN ] ; then
   if [ $PASSMINLEN -gt 7 ] ; then
      echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]양호"  
   else 
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약" 
   fi
else
   echo "[RESULT]취약(설정값이 없습니다.)" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약(설정값이 없습니다.)"
fi

#! /bin/sh

echo "사용자 계정의 UID 범위"
echo "사용자 계정의 UID 범위" >> $HOSTNAME-result.txt 2>&1
UID_MIN=`grep UID_MIN /etc/login.defs | grep -v "^#" | awk '/1000/{ print $2 }'`
UID_MAX=`grep UID_MAX /etc/login.defs | grep -v "^#" | awk '/60000/{ print $2 }'`
if [[ $UID_MIN ]] && [[ $UID_MAX ]] ; then
   if [ $UID_MIN -eq 1000 ] ; then
      if [ $UID_MAX -eq 60000 ] ; then
         echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
         echo " " >> $HOSTNAME-result.txt 2>&1
         echo "[RESULT]양호" 
      else
         echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
         echo " " >> $HOSTNAME-result.txt 2>&1
         echo "[RESULT]취약"
      fi
   else
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약"
   fi
else
   echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약"
fi

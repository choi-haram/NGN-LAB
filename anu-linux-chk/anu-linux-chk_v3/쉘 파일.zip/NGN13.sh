#! /bin/sh

echo "시스템 계정의 UID 범위"
echo "시스템 계정의 UID 범위" >> $HOSTNAME-result.txt 2>&1
SYS_UID_MIN=`grep UID_MIN /etc/login.defs | grep -v "^#" | awk '/201/{ print $2 }'`
SYS_UID_MAX=`grep UID_MAX /etc/login.defs | grep -v "^#" | awk '/999/{ print $2 }'`
if [[ $SYS_UID_MIN ]] && [[ $SYS_UID_MAX ]] ; then
   if [ $SYS_UID_MIN -eq 201 ] ; then
      if [ $SYS_UID_MAX -eq 999 ] ; then
         echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
         echo " " >> $HOSTNAME-result.txt 2>&1
         echo "[RESULT]양호"
      else
         echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
         echo " " >> $HOSTNAME-result.txt 2>&1
         echo "[RESULT]취약"
      fi
   else
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약"
   fi
else
   echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약"
fi 

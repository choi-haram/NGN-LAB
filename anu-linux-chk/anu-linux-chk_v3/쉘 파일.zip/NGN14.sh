#! /bin/sh

echo "사용자 계정의 GID 범위"
echo "사용자 계정의 GID 범위" >> $HOSTNAME-result.txt 2>&1
GID_MIN=`grep GID_MIN /etc/login.defs | grep -v "^#" | awk '/1000/{ print $2 }'`
GID_MAX=`grep GID_MAX /etc/login.defs | grep -v "^#" | awk '/60000/{ print $2 }'`
if [[ $GID_MIN ]] && [[ $GID_MAX ]] ; then
   if [ $GID_MIN -eq 1000 ] ; then
      if [ $GID_MAX -eq 60000 ] ; then
         echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
         echo " " >> $HOSTNAME-result.txt 2>&1
         echo "[RESULT]양호" 
      else
         echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
         echo " " >> $HOSTNAME-result.txt 2>&1
         echo "[RESULT]취약"
      fi
   else
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약"
   fi
else
   echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약"
fi

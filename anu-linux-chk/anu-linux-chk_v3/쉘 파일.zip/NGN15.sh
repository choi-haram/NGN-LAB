#! /bin/sh

echo "시스템 계정의 GID 범위"
echo "시스템 계정의 GID 범위" >> $HOSTNAME-result.txt 2>&1
SYS_GID_MIN=`grep GID_MIN /etc/login.defs | grep -v "^#" | awk '/201/{ print $2 }'`
SYS_GID_MAX=`grep GID_MAX /etc/login.defs | grep -v "^#" | awk '/999/{ print $2 }'`
if [[ $SYS_GID_MIN ]] && [[ $SYS_GID_MAX ]] ; then
   if [ $SYS_GID_MIN -eq 201 ] ; then
      if [ $SYS_GID_MAX -eq 999 ] ; then
         echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
         echo " " >> $HOSTNAME-result.txt 2>&1
         echo "[RESULT]양호"
      else
         echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
         echo " " >> $HOSTNAME-result.txt 2>&1
         echo "[RESULT]취약"
      fi
   else
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약"
   fi
else
   echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약"
fi 

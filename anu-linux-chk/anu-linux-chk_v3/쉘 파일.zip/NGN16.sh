#! /bin/sh

echo "사용자 계정 삭제시 그룹 삭제 여부"
echo "사용자 계정 삭제시 그룹 삭제 여부" >> $HOSTNAME-result.txt 2>&1
USERGROUPSENAB=`grep USERGROUPS_ENAB /etc/login.defs | grep -v "^#" | awk '{ print$2 }'`
if [ $USERGROUPSENAB ] ; then
   if [ $USERGROUPSENAB == 'yes' ] ; then
      echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]양호" 
   else
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약"
   fi
else
   echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약"
fi


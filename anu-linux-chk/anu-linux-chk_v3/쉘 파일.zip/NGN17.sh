#! /bin/sh

echo "암호화 기법 설정"
echo "암호화 기법 설정" >> $HOSTNAME-result.txt 2>&1
ENCRYPTMETHOD=`grep ENCRYPT_METHOD /etc/login.defs | grep -v "^#" | awk '{ print$2 }'`
if [ $ENCRYPTMETHOD ] ; then
   if [ $ENCRYPTMETHOD == 'SHA512' ] ; then
      echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]양호"
   else
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약"
   fi
else
   echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약"
fi



#! /bin/sh

echo "각기 다른 문자의 조합 수"
echo "각기 다른 문자의 조합 수" >> $HOSTNAME-result.txt 2>&1
MINCLASS=`grep minclass /etc/security/pwquality.conf | grep -v "^#" | awk '{ print $3 }'`
if [ $MINCLASS ] ; then
   if [ $MINCLASS -eq 3 ] ; then
      echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]양호" 
   else 
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약"      
   fi
else
   echo "[RESULT]취약(설정값이 없습니다.)" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약(설정값이 없습니다.)"
fi

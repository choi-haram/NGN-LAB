#! /bin/sh

echo "연속으로 같은 종류의 사용 허용"
echo "연속으로 같은 종류의 사용 허용" >> $HOSTNAME-result.txt 2>&1
MAXCLASSREPEAT=`grep maxclassrepeat /etc/security/pwquality.conf | grep -v "^#" | awk '{ print $3 }'`
if [ $MAXCLASSREPEAT ] ; then
   if [ $MAXCLASSREPEAT -ge 0 ] ; then
      echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]양호" 
   else 
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약"      
   fi
else
   echo "[RESULT]취약(설정값이 없습니다.)" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약(설정값이 없습니다.)"
fi

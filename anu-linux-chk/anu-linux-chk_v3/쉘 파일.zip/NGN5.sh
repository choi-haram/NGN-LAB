#! /bin/sh

echo "로그인 실패 시 차단 설정"
echo "로그인 실패 시 차단 설정" >> $HOSTNAME-result.txt 2>&1
DENY=`cat /etc/pam.d/system-auth | grep -v "^#" | awk '{ print $4 }' | grep deny=5`
UNLOCK_TIME=`cat /etc/pam.d/system-auth | grep -v "^#" | awk '{ print $5}' | grep unlock_time=300`
if [ $DENY ] ; then
   if [ $UNLOCK_TIME ] ; then
      echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]양호"
      echo " " >> $HOSTNAME-result.txt 2>&1
   else
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약"
      echo " " >> $HOSTNAME-result.txt 2>&1
   fi
else
   echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약"
   echo " " >> $HOSTNAME-result.txt 2>&1
fi

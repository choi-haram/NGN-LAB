#! /bin/sh

echo "계정이 존재하지 않는 GID 금지"
echo "계정이 존재하지 않는 GID 금지" >> $HOSTNAME-result.txt 2>&1
X=$((0))
File_group=`cat /etc/group | awk -F":" '{print $1}' `
for id in $File_group
do
   if [ `cat /etc/passwd | grep "$id:" | wc -l` -eq 0 ] ; then
      echo `cat /etc/group | grep "$id:"` >> $HOSTNAME-result.txt 2>&1
      if [[ `cat /etc/group | grep "$id:" | awk -F":" '{print $3}'` == "x" ]] ; then
         X=$((0))
      else
         X=$((2))                        
      fi
   fi
done
if [ -z `cat /etc/group | grep "$id:" | awk -F":" '{print $4}'` ] ; then
   X=$((2))
else
   X=$((0))
fi
if [ $X -eq 2 ] ; then
   echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약"
   echo " " >> $HOSTNAME-result.txt 2>&1
else
   echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]양호" 
   echo " " >> $HOSTNAME-result.txt 2>&1
fi


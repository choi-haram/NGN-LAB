#! /bin/sh

echo "Session Timeout 설정" 
echo "Session Timeout 설정" >> $HOSTNAME-result.txt 2>&1

if [ -f /etc/profile ] ; then
   echo "" >> $HOSTNAME-result.txt 2>&1
else
	echo "/etc/profile 파일이 없습니다." >> $HOSTNAME-result.txt 2>&1
fi
if [ -f /etc/csh.login ] ; then
   echo "" >> $HOSTNAME-result.txt 2>&1
else
	echo "/etc/csh.login 파일이 없습니다."  >> $HOSTNAME-result.txt 2>&1
fi

if [ -f /etc/profile ] ; then
	if [ `cat /etc/profile | grep -v "#" | egrep 'TMOUT|TIMEOUT' | grep -v '[0-9]600' | grep '600$' | wc -l ` -eq 1 ] ; then
		echo "[RESULT]양호"
		echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
		echo " "  >> $HOSTNAME-result.txt 2>&1
	else
		if [ -f /etc/csh.login ] ; then
			if [ `cat /etc/csh.login  | grep -v "#" | egrep 'autologout' | grep -v '[0-9]10' | grep '10$' | wc -l ` -eq 1 ] ; then
				echo "[RESULT]양호"
				echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
				echo " " >> $HOSTNAME-result.txt 2>&1
			else
				echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
				echo " " >> $HOSTNAME-result.txt 2>&1
			fi
		else
			echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
			echo " " >> $HOSTNAME-result.txt 2>&1
		fi
	fi
else
	if [ -f /etc/csh.login  ] ; then
		if [ `cat /etc/csh.login  | grep -v "#" | egrep 'autologout' | grep -v '[0-9]10' | grep '10$' | wc -l ` -eq 1 ] ; then
			echo "[RESULT]양호"
			echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
			echo " " >> $HOSTNAME-result.txt 2>&1
		else 
			echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
			echo " " >> $HOSTNAME-result.txt 2>&1
		fi
	else 
		echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
		echo " " >> $HOSTNAME-result.txt 2>&1
	fi
fi  


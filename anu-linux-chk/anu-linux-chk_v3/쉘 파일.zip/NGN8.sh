#! /bin/sh

echo "패스워드 최대 사용 기간 설정"
echo "패스워드 최대 사용 기간 설정" >> $HOSTNAME-result.txt 2>&1
PASSMAXDAYS=`grep PASS_MAX_DAYS /etc/login.defs | grep -v "^#" | awk '{ print $2 }'`
if [ $PASSMAXDAYS ] ; then
   if [ $PASSMAXDAYS -gt 90 ] ; then 
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약" 
   else 
      echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]양호" 
   fi
else
   echo "[RESULT]취약(설정값이 없습니다.)" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약(설정값이 없습니다.)"
fi

#! /bin/sh

echo "패스워드 최소 사용 기간 설정"
echo "패스워드 최소 사용 기간 설정" >> $HOSTNAME-result.txt 2>&1
PASSMINDAYS=`grep PASS_MIN_DAYS /etc/login.defs | grep -v "^#" | awk '{ print $2 }'`
if [ $PASSMINDAYS ] ; then
   if [ $PASSMINDAYS -ge 1 ] ; then 
      echo "[RESULT]양호" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]양호"
   else 
      echo "[RESULT]취약" >> $HOSTNAME-result.txt 2>&1
      echo " " >> $HOSTNAME-result.txt 2>&1
      echo "[RESULT]취약"       
   fi
else
   echo "[RESULT]취약(설정값이 없습니다.)" >> $HOSTNAME-result.txt 2>&1
   echo " " >> $HOSTNAME-result.txt 2>&1
   echo "[RESULT]취약(설정값이 없습니다.)"
fi
